package com.alraisi.aluminum.data.db

/** القطاعات الافتراضية للنظام العادي الشعبي — كل القواعد قابلة للتعديل من شاشة القطاعات */
object Seed {

    fun profiles(): List<ProfileEntity> = listOf(
        // ---------- الإطارات ----------
        ProfileEntity(
            id = "frame_tube44", name = "Tube Frame 4x4", nameAr = "تيوب مرد 4×4",
            category = "FRAME", widthCm = 4.0, depthCm = 4.0, defaultAngle = 45.0,
            pricePerMeter = 18.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 0.6", dividerF = "span - topCover - bottomCover + 0.2",
            fixedF = "opening", compatBerklozId = "berk_square"
        ),
        ProfileEntity(
            id = "frame_halaq_in75", name = "Internal Halaq 7.5", nameAr = "حلق داخلي 7.5 سم",
            category = "FRAME", widthCm = 7.5, depthCm = 7.5, defaultAngle = 45.0,
            pricePerMeter = 22.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 0.6", dividerF = "span - topCover - bottomCover + 0.2",
            fixedF = "opening", compatBerklozId = "berk_rolled"
        ),
        ProfileEntity(
            id = "frame_halaq_out75", name = "External Halaq 7.5", nameAr = "حلق خارجي 7.5 سم",
            category = "FRAME", widthCm = 7.5, depthCm = 7.5, defaultAngle = 45.0,
            pricePerMeter = 24.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 0.6", dividerF = "span - topCover - bottomCover + 0.2",
            fixedF = "opening", compatBerklozId = "berk_rolled"
        ),

        // ---------- الدرفات ----------
        ProfileEntity(
            id = "sash_rolled55", name = "Rolled Sash 5.5", nameAr = "درفة ملفوفة 5.5 سم",
            category = "SASH", widthCm = 5.5, depthCm = 2.5, defaultAngle = 45.0,
            pricePerMeter = 20.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 1.2", dividerF = "span", fixedF = "opening",
            compatBerklozId = "berk_rolled"
        ),
        ProfileEntity(
            id = "sash_door65", name = "Door Sash 6.5", nameAr = "درفة باب 6.5 سم",
            category = "SASH", widthCm = 6.5, depthCm = 4.0, defaultAngle = 45.0,
            pricePerMeter = 26.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 1.2", dividerF = "span", fixedF = "opening",
            compatBerklozId = "berk_square"
        ),
        ProfileEntity(
            id = "sash_door45", name = "Door Sash 4.5", nameAr = "درفة باب 4.5 سم",
            category = "SASH", widthCm = 4.5, depthCm = 3.0, defaultAngle = 45.0,
            pricePerMeter = 21.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 1.2", dividerF = "span", fixedF = "opening",
            compatBerklozId = "berk_square"
        ),
        ProfileEntity(
            id = "sash_net", name = "Net Sash", nameAr = "درفة سلك نامس",
            category = "NET", widthCm = 2.0, depthCm = 1.5, defaultAngle = 45.0,
            pricePerMeter = 9.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "0", dividerF = "span", fixedF = "opening"
        ),

        // ---------- القواطع ----------
        ProfileEntity(
            id = "div_large65", name = "Large Divider 6.5", nameAr = "قاطع عريض 6.5 سم",
            category = "DIVIDER", widthCm = 6.5, depthCm = 4.0, defaultAngle = 90.0,
            pricePerMeter = 24.0,
            externalF = "opening", internalF = "opening - width",
            glassF = "w - 2*width - 0.6", dividerF = "span - topCover - bottomCover + 0.2",
            fixedF = "opening", compatBerklozId = "berk_square"
        ),
        ProfileEntity(
            id = "div_small45", name = "Small Divider 4.5", nameAr = "قاطع صغير 4.5 سم",
            category = "DIVIDER", widthCm = 4.5, depthCm = 3.0, defaultAngle = 90.0,
            pricePerMeter = 19.0,
            externalF = "opening", internalF = "opening - width",
            glassF = "w - 2*width - 0.6", dividerF = "span - topCover - bottomCover + 0.2",
            fixedF = "opening", compatBerklozId = "berk_square"
        ),

        // ---------- الثابت والشرائح ----------
        ProfileEntity(
            id = "fixed_std", name = "Fixed Section", nameAr = "ثابت",
            category = "FIXED", widthCm = 4.0, depthCm = 4.0, defaultAngle = 45.0,
            pricePerMeter = 16.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 0.6", dividerF = "span", fixedF = "opening",
            compatBerklozId = "berk_square"
        ),
        ProfileEntity(
            id = "slide_4", name = "Slide 4cm", nameAr = "شريحة 4 سم",
            category = "SLIDE", widthCm = 4.0, depthCm = 2.0, defaultAngle = 90.0,
            pricePerMeter = 8.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 0.6", dividerF = "span", fixedF = "opening",
            compatBerklozId = "berk_rolled"
        ),
        ProfileEntity(
            id = "slide_8", name = "Slide 8cm", nameAr = "شريحة 8 سم",
            category = "SLIDE", widthCm = 8.0, depthCm = 2.5, defaultAngle = 90.0,
            pricePerMeter = 12.0,
            externalF = "opening", internalF = "opening - 2*width",
            glassF = "w - 2*width - 0.6", dividerF = "span", fixedF = "opening",
            compatBerklozId = "berk_rolled"
        ),

        // ---------- مواسير الحماية ----------
        ProfileEntity(
            id = "prot_twisted", name = "Twisted Protection Tube", nameAr = "مواسير حماية مبروم",
            category = "PROTECTION", widthCm = 2.0, depthCm = 2.0, defaultAngle = 90.0,
            pricePerMeter = 7.0,
            externalF = "opening", internalF = "opening",
            glassF = "0", dividerF = "span", fixedF = "opening"
        ),
        ProfileEntity(
            id = "prot_square", name = "Square Protection Tube 3x1.5", nameAr = "مواسير حماية مربع 3×1.5 سم",
            category = "PROTECTION", widthCm = 3.0, depthCm = 1.5, defaultAngle = 90.0,
            pricePerMeter = 8.0,
            externalF = "opening", internalF = "opening",
            glassF = "0", dividerF = "span", fixedF = "opening"
        ),

        // ---------- البركلوز ----------
        ProfileEntity(
            id = "berk_rolled", name = "Rolled Berkloz", nameAr = "بركلوز ملفوف",
            category = "BERKLOZ", widthCm = 1.5, depthCm = 1.0, defaultAngle = 90.0,
            pricePerMeter = 5.0,
            externalF = "opening", internalF = "opening",
            glassF = "0", dividerF = "span", fixedF = "opening", berklozCoverCm = 1.2
        ),
        ProfileEntity(
            id = "berk_square", name = "Square Berkloz 90", nameAr = "بركلوز مربع 90 درجة",
            category = "BERKLOZ", widthCm = 1.8, depthCm = 1.2, defaultAngle = 90.0,
            pricePerMeter = 6.0,
            externalF = "opening", internalF = "opening",
            glassF = "0", dividerF = "span", fixedF = "opening", berklozCoverCm = 1.5
        )
    )

    fun accessoryRules(): List<AccessoryRuleEntity> = listOf(
        AccessoryRuleEntity("acc_hinge", "مفصلات درفة", "مفصلات", conditionF = "hingedSash > 0", qtyF = "2*hingedSash", unitPrice = 8.0),
        AccessoryRuleEntity("acc_door_hinge", "مفصلات باب", "مفصلات", conditionF = "hingedDoor > 0", qtyF = "3*hingedDoor", unitPrice = 15.0),
        AccessoryRuleEntity("acc_handle", "مقابض / يد", "مقابض", conditionF = "sashCount > 0", qtyF = "sashCount", unitPrice = 25.0),
        AccessoryRuleEntity("acc_lock", "أقفال", "أقفال", conditionF = "hingedCount > 0", qtyF = "hingedCount", unitPrice = 45.0),
        AccessoryRuleEntity("acc_roller", "رولات / كاستر (سحاب)", "رولات", conditionF = "slidingCount > 0", qtyF = "2*slidingCount", unitPrice = 12.0),
        AccessoryRuleEntity("acc_tilt", "إكسسوار قلاب / Tilt", "قلاب", conditionF = "tiltCount > 0", qtyF = "tiltCount", unitPrice = 60.0),
        AccessoryRuleEntity("acc_latch", "سقاطة / مزلاج", "سقاطات", conditionF = "sashCount > 0", qtyF = "sashCount", unitPrice = 10.0),
        AccessoryRuleEntity("acc_rubber", "سيليكون / لاصق زجاج", "سدادات", conditionF = "glassCount > 0", qtyF = "glassPerimeter*0.1", unitPrice = 15.0),
        AccessoryRuleEntity("acc_brush", "فرشاة / شريط سد (متر)", "سدادات", conditionF = "sashCount > 0", qtyF = "sashPerimeter", unitPrice = 2.0),
        AccessoryRuleEntity("acc_spacer", "فواصل بلاستيكية", "فواصل", conditionF = "glassCount > 0", qtyF = "4*glassCount", unitPrice = 1.0),
        AccessoryRuleEntity("acc_moist", "ماص رطوبة", "فواصل", conditionF = "glassCount > 0", qtyF = "glassCount", unitPrice = 3.0),
        AccessoryRuleEntity("acc_screw", "براغي تثبيت (علبة)", "أخرى", conditionF = "1", qtyF = "1", unitPrice = 10.0)
    )

    fun workshop() = WorkshopEntity()
    fun settings() = SettingsEntity()
}
