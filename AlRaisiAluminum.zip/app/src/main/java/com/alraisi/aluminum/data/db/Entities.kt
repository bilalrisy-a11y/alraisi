package com.alraisi.aluminum.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * قاعدة بيانات القطاعات. كل قاعدة قص عبارة عن نص معادلة قابل للتعديل من شاشة "القطاعات"
 * المتغيرات المتاحة:
 *  opening / w / h : الأبعاد الخارجية للعنصر
 *  width, depth    : مقطع القطاع
 *  span            : المسافة الصافية بين العناصر المحيطة (للقواطع)
 *  topCover, bottomCover, leftCover, rightCover : سماكات المحيطين
 *  count           : عدد العناصر من نفس النوع
 */
@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String = "",
    val nameAr: String,
    val category: String, // FRAME / SASH / DIVIDER / SLIDE / FIXED / NET / PROTECTION / BERKLOZ
    val widthCm: Double = 4.0,
    val depthCm: Double = 4.0,
    val defaultAngle: Double = 45.0,
    val pricePerMeter: Double = 0.0,
    val externalF: String = "opening",                       // قاعدة القص الخارجي (45°)
    val internalF: String = "opening - 2*width",             // القاعدة الداخلية
    val glassF: String = "w - 2*width - 0.6",                // قاعدة الزجاج
    val dividerF: String = "span - topCover - bottomCover + 0.2", // قاعدة القاطع (90°)
    val fixedF: String = "opening",                          // قاعدة الثابت
    val berklozCoverCm: Double = 1.2,                        // تغطية البركلوز
    val compatBerklozId: String = "berk_rolled",
    val imagePath: String = "",
    val crossSectionPath: String = "",
    val system: String = "ordinary",                         // النظام (للتوسع المستقبلي)
    val active: Boolean = true
)

@Entity(tableName = "accessory_rules")
data class AccessoryRuleEntity(
    @PrimaryKey val id: String,
    val nameAr: String,
    val category: String, // مفصلات / مقابض / أقفال / رولات / سدادات / أخرى
    val conditionF: String = "1",
    val qtyF: String = "0",
    val unitPrice: Double = 0.0,
    val active: Boolean = true
)

@Entity(tableName = "workshop")
data class WorkshopEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "Al-Raisi Aluminum Workshop",
    val nameAr: String = "ورشة الريسي للألومنيوم",
    val phone: String = "",
    val address: String = "",
    val logoPath: String = ""
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val notes: String = ""
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val name: String,
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "designs")
data class DesignEntity(
    @PrimaryKey val id: String,
    val projectId: String = "",
    val name: String,
    val docJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val barLengthCm: Double = 600.0,
    val glassPricePerM2: Double = 0.0,
    val glassThicknessMm: Double = 5.0,
    val rubberPricePerM: Double = 2.0,
    val laborPerM2: Double = 0.0,
    val laborFixed: Double = 0.0,
    val transport: Double = 0.0,
    val otherCosts: Double = 0.0,
    val profitMarginPct: Double = 25.0,
    val currency: String = "ريال"
)
