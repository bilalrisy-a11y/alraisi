package com.alraisi.aluminum.core.calc

import com.alraisi.aluminum.core.model.BarCut
import com.alraisi.aluminum.core.model.BarPlan

/**
 * تحسين القص على مواسير 6 متر:
 * تجميع القطع المتطابقة + First-Fit-Decreasing لتقليل الهالك.
 */
object BarOptimizer {

    private const val KERF_CM = 0.3 // سماكة الشفرة

    data class CutRequest(
        val profileId: String,
        val profileName: String,
        val lengthCm: Double,
        val qty: Int,
        val label: String
    )

    fun optimize(requests: List<CutRequest>, barLengthCm: Double): List<BarPlan> {
        val plans = mutableListOf<BarPlan>()
        requests.groupBy { it.profileId }.forEach { (_, group) ->
            val name = group.first().profileName
            val cuts = group.flatMap { r ->
                List(r.qty.coerceAtLeast(0)) { BarCut(r.lengthCm, r.label) }
            }.filter { it.lengthCm in 0.01..barLengthCm }
                .sortedByDescending { it.lengthCm }

            val bars = mutableListOf<MutableList<BarCut>>()
            for (cut in cuts) {
                val fit = bars.firstOrNull { bar ->
                    bar.sumOf { it.lengthCm } + cut.lengthCm + KERF_CM * bar.size <= barLengthCm - KERF_CM
                }
                if (fit != null) fit += cut else bars += mutableListOf(cut)
            }
            bars.forEachIndexed { i, bar ->
                val used = bar.sumOf { it.lengthCm } + KERF_CM * (bar.size - 1).coerceAtLeast(0)
                plans += BarPlan(
                    profileName = name,
                    barIndex = i + 1,
                    cuts = bar.toList(),
                    usedCm = Calculator.round1(used),
                    remainingCm = Calculator.round1((barLengthCm - used).coerceAtLeast(0.0))
                )
            }
        }
        return plans
    }
}
