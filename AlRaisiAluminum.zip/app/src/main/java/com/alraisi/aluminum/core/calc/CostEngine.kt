package com.alraisi.aluminum.core.calc

import com.alraisi.aluminum.core.model.*
import com.alraisi.aluminum.data.db.ProfileEntity
import com.alraisi.aluminum.data.db.SettingsEntity

/** محرك التكاليف: مواد + زجاج + إكسسوارات + بركلوز + سدادات + أجور + نقل + أخرى */
object CostEngine {

    fun compute(
        cutting: List<CuttingItem>,
        glass: List<GlassItem>,
        accessories: List<AccessoryItem>,
        berklozItems: List<BerklozItem>,
        berklozProfiles: List<ProfileEntity>,
        sashPerimeterM: Double,
        settings: SettingsEntity,
        openingAreaM2: Double,
        profiles: List<ProfileEntity>
    ): CostBreakdown {
        val priceById = profiles.associate { it.id to it.pricePerMeter }

        val aluminumCost = cutting.sumOf { item ->
            val p = priceById[item.profileId] ?: 0.0
            item.lengthCm * item.quantity / 100.0 * p
        }
        val berklozCost = berklozItems.sumOf { item ->
            val p = berklozProfiles.firstOrNull { it.nameAr == item.berklozName }?.pricePerMeter ?: 0.0
            item.lengthCm / 100.0 * p
        }
        val rubberCost = sashPerimeterM * settings.rubberPricePerM
        val glassCost = glass.sumOf { it.areaM2 } * settings.glassPricePerM2
        val accessoryCost = accessories.sumOf { it.total }
        val laborCost = openingAreaM2 * settings.laborPerM2 + settings.laborFixed

        return CostBreakdown(
            aluminumCost = Calculator.round2(aluminumCost),
            berklozCost = Calculator.round2(berklozCost),
            rubberCost = Calculator.round2(rubberCost),
            glassCost = Calculator.round2(glassCost),
            accessoryCost = Calculator.round2(accessoryCost),
            laborCost = Calculator.round2(laborCost),
            transport = settings.transport,
            other = settings.otherCosts
        )
    }
}
