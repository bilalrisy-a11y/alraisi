package com.alraisi.aluminum.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles WHERE active = 1 ORDER BY category, nameAr")
    fun observeActive(): Flow<List<ProfileEntity>>
    @Query("SELECT * FROM profiles ORDER BY category, nameAr")
    fun observeAll(): Flow<List<ProfileEntity>>
    @Query("SELECT * FROM profiles")
    suspend fun all(): List<ProfileEntity>
    @Query("SELECT * FROM profiles WHERE id = :id")
    suspend fun byId(id: String): ProfileEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: ProfileEntity)
    @Delete
    suspend fun delete(p: ProfileEntity)
}

@Dao
interface AccessoryRuleDao {
    @Query("SELECT * FROM accessory_rules")
    fun observeAll(): Flow<List<AccessoryRuleEntity>>
    @Query("SELECT * FROM accessory_rules")
    suspend fun all(): List<AccessoryRuleEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(r: AccessoryRuleEntity)
    @Delete
    suspend fun delete(r: AccessoryRuleEntity)
}

@Dao
interface WorkshopDao {
    @Query("SELECT * FROM workshop WHERE id = 1")
    fun observe(): Flow<WorkshopEntity?>
    @Query("SELECT * FROM workshop WHERE id = 1")
    suspend fun get(): WorkshopEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(w: WorkshopEntity)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY name")
    fun observeAll(): Flow<List<CustomerEntity>>
    @Query("SELECT * FROM customers")
    suspend fun all(): List<CustomerEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(c: CustomerEntity)
    @Delete
    suspend fun delete(c: CustomerEntity)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY date DESC")
    fun observeAll(): Flow<List<ProjectEntity>>
    @Query("SELECT * FROM projects WHERE customerId = :customerId")
    fun observeForCustomer(customerId: String): Flow<List<ProjectEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: ProjectEntity)
    @Delete
    suspend fun delete(p: ProjectEntity)
}

@Dao
interface DesignDao {
    @Query("SELECT * FROM designs ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<DesignEntity>>
    @Query("SELECT * FROM designs WHERE projectId = :projectId")
    fun observeForProject(projectId: String): Flow<List<DesignEntity>>
    @Query("SELECT * FROM designs WHERE id = :id")
    suspend fun byId(id: String): DesignEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(d: DesignEntity)
    @Query("DELETE FROM designs WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings WHERE id = 1")
    fun observe(): Flow<SettingsEntity?>
    @Query("SELECT * FROM settings WHERE id = 1")
    suspend fun get(): SettingsEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: SettingsEntity)
}
