package com.alraisi.aluminum.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.alraisi.aluminum.data.ServiceLocator
import com.alraisi.aluminum.data.db.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ScreenScaffold(nav: NavController, title: String, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, "رجوع") } }
            )
        },
        content = content
    )
}

@Composable
fun DesignsScreen(nav: NavController) {
    val repo = ServiceLocator.repo
    val designs by repo.designs.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    ScreenScaffold(nav, "التصاميم") { pad ->
        if (designs.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد تصاميم محفوظة — ابدأ من «تصميم جديد»")
            }
            return@ScreenScaffold
        }
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
            items(designs, key = { it.id }) { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), onClick = { nav.navigate("designer/${d.id}") }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, style = MaterialTheme.typography.titleMedium)
                            Text("آخر تعديل: " + java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.getDefault()).format(java.util.Date(d.updatedAt)),
                                style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton({ scope.launch { repo.duplicateDesign(d.id) } }) { Icon(Icons.Default.Add, "نسخ") }
                        IconButton({ scope.launch { repo.deleteDesign(d.id) } }) { Icon(Icons.Default.Delete, "حذف") }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomersScreen(nav: NavController) {
    val repo = ServiceLocator.repo
    val customers by repo.customers.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var show by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var addr by remember { mutableStateOf("") }
    ScreenScaffold(nav, "العملاء") { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (customers.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا يوجد عملاء") }
            LazyColumn(contentPadding = PaddingValues(12.dp)) {
                items(customers, key = { it.id }) { c ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.name, style = MaterialTheme.typography.titleMedium)
                                if (c.phone.isNotBlank() || c.address.isNotBlank())
                                    Text(listOf(c.phone, c.address).filter { it.isNotBlank() }.joinToString(" — "),
                                        style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton({ scope.launch { repo.deleteCustomer(c) } }) { Icon(Icons.Default.Delete, null) }
                        }
                    }
                }
            }
            FloatingActionButton({ show = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Icon(Icons.Default.Add, "إضافة") }
        }
    }
    if (show) AlertDialog(
        onDismissRequest = { show = false },
        title = { Text("عميل جديد") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("الاسم") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text("الهاتف") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(addr, { addr = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton({
                if (name.isNotBlank()) scope.launch { repo.saveCustomer(CustomerEntity(UUID.randomUUID().toString(), name, phone, addr)) }
                show = false
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton({ show = false }) { Text("إلغاء") } }
    )
}

@Composable
fun ProjectsScreen(nav: NavController) {
    val repo = ServiceLocator.repo
    val projects by repo.projects.collectAsState(initial = emptyList())
    val customers by repo.customers.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var show by remember { mutableStateOf(false) }
    var pname by remember { mutableStateOf("") }
    var cid by remember { mutableStateOf("") }
    ScreenScaffold(nav, "المشاريع") { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (projects.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد مشاريع") }
            LazyColumn(contentPadding = PaddingValues(12.dp)) {
                items(projects, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.titleMedium)
                                Text("العميل: " + (customers.firstOrNull { it.id == p.customerId }?.name ?: "—"),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton({ scope.launch { repo.deleteProject(p) } }) { Icon(Icons.Default.Delete, null) }
                        }
                    }
                }
            }
            FloatingActionButton({ show = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Icon(Icons.Default.Add, "إضافة") }
        }
    }
    if (show) AlertDialog(
        onDismissRequest = { show = false },
        title = { Text("مشروع جديد") },
        text = {
            Column {
                OutlinedTextField(pname, { pname = it }, label = { Text("اسم المشروع") }, modifier = Modifier.fillMaxWidth())
                Text("العميل:", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp))
                customers.forEach { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = cid == c.id, onClick = { cid = c.id })
                        Text(c.name)
                    }
                }
                if (customers.isEmpty()) Text("أضف عميلاً أولاً من شاشة العملاء", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton({
                if (pname.isNotBlank() && cid.isNotBlank())
                    scope.launch { repo.saveProject(ProjectEntity(UUID.randomUUID().toString(), cid, pname)) }
                show = false
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton({ show = false }) { Text("إلغاء") } }
    )
}
