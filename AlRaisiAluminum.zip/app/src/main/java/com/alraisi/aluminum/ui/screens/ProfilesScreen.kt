package com.alraisi.aluminum.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.alraisi.aluminum.data.ServiceLocator
import com.alraisi.aluminum.data.db.ProfileEntity
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun ProfilesScreen(nav: NavController) {
    val repo = ServiceLocator.repo
    val profiles by repo.allProfiles.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<ProfileEntity?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<ProfileEntity?>(null) }

    ScreenScaffold(nav, "القطاعات وقواعد القص") { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            LazyColumn(contentPadding = PaddingValues(12.dp)) {
                items(profiles, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), onClick = { editing = p }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.nameAr + if (!p.active) " (معطّل)" else "",
                                    style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${p.category} | عرض ${p.widthCm} سم | زاوية ${p.defaultAngle}° | ${p.pricePerMeter}/م",
                                    style = MaterialTheme.typography.bodySmall)
                                Text("قاعدة خارجية: ${p.externalF} | قاطع: ${p.dividerF}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton({ confirmDelete = p }) { Icon(Icons.Default.Delete, null) }
                        }
                    }
                }
            }
            FloatingActionButton(
                { showNew = true },
                Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) { Icon(Icons.Default.Add, "إضافة قطاع") }
        }
    }

    editing?.let { p -> ProfileDialog(p, { editing = null }) { scope.launch { repo.saveProfile(it) } } }
    if (showNew) ProfileDialog(
        ProfileEntity(id = UUID.randomUUID().toString().take(12), nameAr = "", category = "SASH"),
        { showNew = false }
    ) { scope.launch { repo.saveProfile(it) } }
    confirmDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("حذف القطاع") },
            text = { Text("حذف «${p.nameAr}» نهائياً؟") },
            confirmButton = {
                TextButton({ scope.launch { repo.deleteProfile(p) }; confirmDelete = null }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton({ confirmDelete = null }) { Text("إلغاء") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileDialog(p: ProfileEntity, onClose: () -> Unit, onSave: (ProfileEntity) -> Unit) {
    var e by remember { mutableStateOf(p) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("قطاع: " + p.nameAr.ifBlank { "جديد" }) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PF("الاسم العربي", e.nameAr) { e = e.copy(nameAr = it) }
                PF("الاسم الإنجليزي", e.name) { e = e.copy(name = it) }
                PF("الفئة: FRAME/SASH/DIVIDER/FIXED/SLIDE/NET/PROTECTION/BERKLOZ", e.category) { e = e.copy(category = it.uppercase()) }
                PF("العرض (سم)", e.widthCm.toString()) { e = e.copy(widthCm = it.toDoubleOrNull() ?: e.widthCm) }
                PF("العمق (سم)", e.depthCm.toString()) { e = e.copy(depthCm = it.toDoubleOrNull() ?: e.depthCm) }
                PF("زاوية القص الافتراضية", e.defaultAngle.toString()) { e = e.copy(defaultAngle = it.toDoubleOrNull() ?: e.defaultAngle) }
                PF("السعر لكل متر", e.pricePerMeter.toString()) { e = e.copy(pricePerMeter = it.toDoubleOrNull() ?: e.pricePerMeter) }
                HorizontalDivider()
                Text("قواعد القص (معادلات قابلة للتعديل)", style = MaterialTheme.typography.labelMedium)
                PF("خارجي 45°: opening,width,depth", e.externalF) { e = e.copy(externalF = it) }
                PF("داخلي", e.internalF) { e = e.copy(internalF = it) }
                PF("زجاج: w,width", e.glassF) { e = e.copy(glassF = it) }
                PF("قاطع 90°: span,topCover,bottomCover", e.dividerF) { e = e.copy(dividerF = it) }
                PF("ثابت", e.fixedF) { e = e.copy(fixedF = it) }
                PF("تغطية البركلوز (سم)", e.berklozCoverCm.toString()) { e = e.copy(berklozCoverCm = it.toDoubleOrNull() ?: e.berklozCoverCm) }
                PF("البركلوز المتوافق (id)", e.compatBerklozId) { e = e.copy(compatBerklozId = it) }
                PF("النظام (ordinary/...)", e.system) { e = e.copy(system = it) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = e.active, onCheckedChange = { e = e.copy(active = it) })
                    Text("فعّال")
                }
            }
        },
        confirmButton = { TextButton({ onSave(e); onClose() }) { Text("حفظ") } },
        dismissButton = { TextButton(onClose) { Text("إلغاء") } }
    )
}

@Composable
internal fun PF(label: String, v: String, onV: (String) -> Unit) {
    var t by remember(label) { mutableStateOf(v) }
    OutlinedTextField(
        t, { t = it; onV(it) },
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        textStyle = MaterialTheme.typography.bodySmall,
        modifier = Modifier.fillMaxWidth()
    )
}
