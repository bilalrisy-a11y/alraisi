package com.alraisi.aluminum.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.alraisi.aluminum.data.ServiceLocator
import kotlinx.coroutines.launch

data class HomeEntry(val route: String, val title: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(nav: NavController) {
    val scope = rememberCoroutineScope()
    val workshop by ServiceLocator.repo.workshop.collectAsState(initial = null)

    val entries = listOf(
        HomeEntry("newDesign", "تصميم جديد", Icons.Default.AddCircle),
        HomeEntry("designs", "التصاميم", Icons.Default.List),
        HomeEntry("customers", "العملاء", Icons.Default.Person),
        HomeEntry("projects", "المشاريع", Icons.Default.Build),
        HomeEntry("profiles", "القطاعات", Icons.Default.AccountBox),
        HomeEntry("prices", "الأسعار", Icons.Default.ShoppingCart),
        HomeEntry("costs", "التكاليف", Icons.Default.DateRange),
        HomeEntry("settings", "الإعدادات", Icons.Default.Settings)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(workshop?.nameAr ?: "ورشة الريسي للألومنيوم", fontWeight = FontWeight.Bold)
                        Text("Al-Raisi Aluminum Workshop", style = MaterialTheme.typography.labelSmall)
                    }
                }
            )
        }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(entries) { e ->
                Card(
                    onClick = { nav.navigate(e.route) },
                    modifier = Modifier.fillMaxWidth().height(110.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(e.icon, contentDescription = null, modifier = Modifier.size(36.dp),
                            tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(8.dp))
                        Text(e.title, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
