package com.alraisi.aluminum.ui.designer

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alraisi.aluminum.core.calc.Calculator
import com.alraisi.aluminum.core.geometry.ArchGeometry
import com.alraisi.aluminum.core.model.*
import com.alraisi.aluminum.data.Repository
import com.alraisi.aluminum.data.db.AccessoryRuleEntity
import com.alraisi.aluminum.data.db.DesignEntity
import com.alraisi.aluminum.data.db.ProfileEntity
import com.alraisi.aluminum.data.db.SettingsEntity
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt

class DesignerViewModel(private val repo: Repository, private val designId: String) : ViewModel() {

    var doc by mutableStateOf<DesignDocument?>(null)
        private set
    var result by mutableStateOf<CalcResult?>(null)
        private set
    var profiles by mutableStateOf<List<ProfileEntity>>(emptyList())
        private set
    var settings by mutableStateOf<SettingsEntity?>(null)
        private set
    var rules by mutableStateOf<List<AccessoryRuleEntity>>(emptyList())
        private set
    var selectedId by mutableStateOf<String?>(null)
    var zoom by mutableFloatStateOf(1f)
    var panX by mutableFloatStateOf(0f)
    var panY by mutableFloatStateOf(0f)
    var snapGuide by mutableStateOf<Pair<Double, Double>?>(null) // خطوط الالتقاط أثناء السحب

    private val undoStack = mutableListOf<DesignDocument>()
    private val redoStack = mutableListOf<DesignDocument>()
    private var gestureBase: DesignDocument? = null

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    init {
        viewModelScope.launch {
            profiles = repo.profilesOnce()
            settings = repo.settingsOnce()
            rules = repo.rulesOnce()
            doc = repo.designById(designId)?.let { repo.decodeDoc(it.docJson) }
            recalc()
        }
    }

    private fun frameProfile() = profiles.firstOrNull { it.id == doc?.frameProfileId }
        ?: profiles.firstOrNull { it.category == "FRAME" }

    fun recalc() {
        val d = doc ?: return
        val s = settings ?: return
        result = Calculator.calculate(d, profiles, s, rules)
    }

    // ---------- تراجع / إعادة ----------
    private fun pushUndo() {
        doc?.let { undoStack += it }
        redoStack.clear()
    }
    fun undo() {
        if (undoStack.isEmpty()) return
        doc?.let { redoStack += it }
        doc = undoStack.removeAt(undoStack.lastIndex)
        recalc()
    }
    fun redo() {
        if (redoStack.isEmpty()) return
        doc?.let { undoStack += it }
        doc = redoStack.removeAt(redoStack.lastIndex)
        recalc()
    }

    fun beginGesture() { gestureBase = doc }
    fun gesture(block: (DesignDocument) -> DesignDocument) {
        val cur = doc ?: return
        doc = block(cur)
        recalc()
    }
    fun endGesture() {
        val b = gestureBase
        if (b != null && b != doc) { undoStack += b; redoStack.clear() }
        gestureBase = null
        snapGuide = null
    }

    // ---------- التقاط ----------
    private fun snapValue(v: Double, candidates: List<Double>): Double {
        val near = candidates.filter { abs(it - v) < 0.6 }.minByOrNull { abs(it - v) }
        if (near != null) return near
        return (v * 2).roundToInt() / 2.0 // شبكة 0.5 سم
    }

    private fun clampToArch(c: CanvasComponent): CanvasComponent {
        val o = doc?.opening ?: return c
        if (o.shape != OpeningShape.ARCH) return c
        val topLimit = ArchGeometry.heightAt(c.x + c.w / 2, o.widthCm, o.seatedHeightCm, o.totalHeightCm, o.archMode) - 0.5
        val maxH = topLimit - c.y
        return if (c.h > maxH) c.copy(h = maxH.coerceAtLeast(5.0)) else c
    }

    fun moveComponent(id: String, dx: Double, dy: Double) {
        val d = doc ?: return
        val fw = frameProfile()?.widthCm ?: 4.0
        val W = d.opening.widthCm
        val H = d.opening.effectiveHeight
        gesture { g ->
            g.copy(components = g.components.map { c ->
                if (c.id != id) return@map c
                val xs = mutableListOf(fw, W - fw - c.w)
                val ys = mutableListOf(fw, H - fw - c.h)
                g.components.filter { it.id != id }.forEach { o ->
                    xs += o.x; xs += o.x + o.w - c.w
                    ys += o.y; ys += o.y + o.h - c.h
                }
                var nx = snapValue(c.x + dx, xs)
                var ny = snapValue(c.y + dy, ys)
                nx = nx.coerceIn(fw, W - fw - c.w)
                ny = ny.coerceIn(fw, H - fw - c.h)
                clampToArch(c.copy(x = nx, y = ny))
            })
        }
    }

    enum class Handle { TL, TR, BL, BR }

    fun resizeComponent(id: String, handle: Handle, dx: Double, dy: Double) {
        val d = doc ?: return
        val fw = frameProfile()?.widthCm ?: 4.0
        val W = d.opening.widthCm
        val H = d.opening.effectiveHeight
        gesture { g ->
            g.copy(components = g.components.map { c ->
                if (c.id != id) return@map c
                var x = c.x; var y = c.y; var w = c.w; var h = c.h
                when (handle) {
                    Handle.TL -> { x += dx; y += dy; w -= dx; h -= dy }
                    Handle.TR -> { y += dy; w += dx; h -= dy }
                    Handle.BL -> { x += dx; w -= dx; h += dy }
                    Handle.BR -> { w += dx; h += dy }
                }
                w = w.coerceIn(3.0, W - 2 * fw)
                h = h.coerceIn(3.0, H - 2 * fw)
                x = x.coerceIn(fw, W - fw - w)
                y = y.coerceIn(fw, H - fw - h)
                clampToArch(c.copy(x = x, y = y, w = w, h = h))
            })
        }
    }

    fun setExact(id: String, x: Double?, y: Double?, w: Double?, h: Double?) {
        val d = doc ?: return
        val fw = frameProfile()?.widthCm ?: 4.0
        val W = d.opening.widthCm
        val H = d.opening.effectiveHeight
        mutate {
            it.copy(components = it.components.map { c ->
                if (c.id != id) return@map c
                clampToArch(c.copy(
                    x = (x ?: c.x).coerceIn(fw, W - fw - c.w),
                    y = (y ?: c.y).coerceIn(fw, H - fw - c.h),
                    w = (w ?: c.w).coerceIn(3.0, W - 2 * fw),
                    h = (h ?: c.h).coerceIn(3.0, H - 2 * fw)
                ))
            })
        }
    }

    fun mutate(transform: (DesignDocument) -> DesignDocument) {
        val cur = doc ?: return
        pushUndo()
        doc = transform(cur).apply { updatedAt = System.currentTimeMillis() }
        recalc()
    }

    // ---------- عمليات المكونات ----------
    fun addComponent(profileId: String) {
        val p = profiles.firstOrNull { it.id == profileId } ?: return
        val d = doc ?: return
        val fw = frameProfile()?.widthCm ?: 4.0
        val W = d.opening.widthCm
        val H = d.opening.effectiveHeight
        val kind = when (p.category) {
            "DIVIDER" -> ComponentKind.DIVIDER
            "FIXED" -> ComponentKind.FIXED
            else -> ComponentKind.SASH
        }
        val (w0, h0) = when (p.category) {
            "DIVIDER" -> p.widthCm to (H - 2 * fw)
            "SLIDE" -> (W - 2 * fw) to p.widthCm
            else -> (W - 2 * fw) / 2.0 to (H - 2 * fw) / 2.0
        }
        val c = CanvasComponent(
            profileId = profileId, kind = kind,
            x = fw + 4, y = fw + 4, w = w0 - 8, h = h0 - 8,
            name = p.nameAr
        )
        mutate { it.copy(components = it.components + c) }
        selectedId = c.id
    }

    fun deleteSelected() {
        val id = selectedId ?: return
        mutate { it.copy(components = it.components.filterNot { c -> c.id == id }) }
        selectedId = null
    }

    fun duplicateSelected() {
        val id = selectedId ?: return
        val d = doc ?: return
        val src = d.components.firstOrNull { it.id == id } ?: return
        val copy = src.copy(id = UUID.randomUUID().toString(), x = src.x + 3, y = src.y + 3)
        mutate { it.copy(components = it.components + copy) }
        selectedId = copy.id
    }

    fun rotateSelected() {
        val id = selectedId ?: return
        mutate {
            it.copy(components = it.components.map { c ->
                if (c.id != id) c else c.copy(w = c.h, h = c.w, rotation = (c.rotation + 90) % 180)
            })
        }
    }

    enum class Align { LEFT, RIGHT, TOP, BOTTOM, CENTER }
    fun alignSelected(mode: Align) {
        val id = selectedId ?: return
        val d = doc ?: return
        val fw = frameProfile()?.widthCm ?: 4.0
        val W = d.opening.widthCm
        val H = d.opening.effectiveHeight
        mutate {
            it.copy(components = it.components.map { c ->
                if (c.id != id) return@map c
                when (mode) {
                    Align.LEFT -> c.copy(x = fw)
                    Align.RIGHT -> c.copy(x = W - fw - c.w)
                    Align.TOP -> c.copy(y = fw)
                    Align.BOTTOM -> c.copy(y = H - fw - c.h)
                    Align.CENTER -> c.copy(x = (W - c.w) / 2, y = (H - c.h) / 2)
                }
            })
        }
    }

    fun rename(name: String) = mutate { it.apply { this.name = name } }

    fun save(onDone: () -> Unit = {}) {
        val d = doc ?: return
        viewModelScope.launch {
            repo.saveDesign(DesignEntity(d.id, "", d.name, repo.encodeDoc(d), d.createdAt, d.updatedAt))
            onDone()
        }
    }
}
