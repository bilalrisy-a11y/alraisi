package com.alraisi.aluminum.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProfileEntity::class, AccessoryRuleEntity::class, WorkshopEntity::class,
        CustomerEntity::class, ProjectEntity::class, DesignEntity::class, SettingsEntity::class
    ],
    version = 1, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun accessoryRuleDao(): AccessoryRuleDao
    abstract fun workshopDao(): WorkshopDao
    abstract fun customerDao(): CustomerDao
    abstract fun projectDao(): ProjectDao
    abstract fun designDao(): DesignDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "alraisi.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val d = get(context)
                            Seed.profiles().forEach { d.profileDao().upsert(it) }
                            Seed.accessoryRules().forEach { d.accessoryRuleDao().upsert(it) }
                            d.workshopDao().upsert(Seed.workshop())
                            d.settingsDao().upsert(Seed.settings())
                        }
                    }
                }).build().also { INSTANCE = it }
            }
    }
}
