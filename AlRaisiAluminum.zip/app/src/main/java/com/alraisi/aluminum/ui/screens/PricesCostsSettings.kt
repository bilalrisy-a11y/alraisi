package com.alraisi.aluminum.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.alraisi.aluminum.core.calc.Calculator
import com.alraisi.aluminum.core.model.CalcResult
import com.alraisi.aluminum.core.model.DesignDocument
import com.alraisi.aluminum.data.ServiceLocator
import com.alraisi.aluminum.data.db.SettingsEntity
import com.alraisi.aluminum.data.db.WorkshopEntity
import kotlinx.coroutines.launch

// ==================== الأسعار ====================
@Composable
fun PricesScreen(nav: NavController) {
    val repo = ServiceLocator.repo
    val settingsFlow by repo.settings.collectAsState(initial = null)
    val profiles by repo.profiles.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var s by remember { mutableStateOf<SettingsEntity?>(null) }
    LaunchedEffect(settingsFlow) { if (s == null) s = settingsFlow }

    ScreenScaffold(nav, "الأسعار") { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            s?.let { st ->
                Text("المواد العامة", style = MaterialTheme.typography.titleSmall)
                PF("سعر الزجاج / م²", st.glassPricePerM2.toString()) { v -> s = st.copy(glassPricePerM2 = v) }
                PF("سعر السدادات / متر", st.rubberPricePerM.toString()) { v -> s = st.copy(rubberPricePerM = v) }
                PF("أجور التصنيع / م²", st.laborPerM2.toString()) { v -> s = st.copy(laborPerM2 = v) }
                PF("أجور ثابتة / تصميم", st.laborFixed.toString()) { v -> s = st.copy(laborFixed = v) }
                PF("النقل", st.transport.toString()) { v -> s = st.copy(transport = v) }
                PF("مصاريف أخرى", st.otherCosts.toString()) { v -> s = st.copy(otherCosts = v) }
                PF("هامش الربح %", st.profitMarginPct.toString()) { v -> s = st.copy(profitMarginPct = v) }
                PF("طول ماسورة الألمنيوم (سم)", st.barLengthCm.toString()) { v -> s = st.copy(barLengthCm = v) }
                PF("العملة", st.currency) { v -> s = st.copy(currency = v) }
                Button({ scope.launch { s?.let { repo.saveSettings(it) } } }, Modifier.fillMaxWidth()) {
                    Text("حفظ")
                }
            }
            HorizontalDivider()
            Text("أسعار القطاعات / متر", style = MaterialTheme.typography.titleSmall)
            profiles.forEach { p ->
                PF("${p.nameAr} (${p.category})", p.pricePerMeter.toString()) { v ->
                    scope.launch { repo.saveProfile(p.copy(pricePerMeter = v)) }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ==================== التكاليف ====================
@Composable
fun CostsScreen(nav: NavController) {
    val repo = ServiceLocator.repo
    val designs by repo.designs.collectAsState(initial = emptyList())
    var selId by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<CalcResult?>(null) }
    var currency by remember { mutableStateOf("ريال") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(selId) {
        if (selId.isNotBlank()) {
            val d: DesignDocument? = repo.designById(selId)?.let { repo.decodeDoc(it.docJson) }
            val st = repo.settingsOnce()
            currency = st.currency
            d?.let { result = Calculator.calculate(it, repo.profilesOnce(), st, repo.rulesOnce()) }
        }
    }

    ScreenScaffold(nav, "التكاليف") { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)) {
            var ex by remember { mutableStateOf(false) }
            Box {
                OutlinedButton({ ex = true }, Modifier.fillMaxWidth()) {
                    Text(designs.firstOrNull { it.id == selId }?.name ?: "اختر تصميماً")
                }
                DropdownMenu(ex, { ex = false }) {
                    designs.forEach { d -> DropdownMenuItem({ Text(d.name) }, { selId = d.id; ex = false }) }
                }
            }
            result?.let { r ->
                val c = r.cost
                RowTv("الألمنيوم", c.aluminumCost, currency)
                RowTv("البركلوز", c.berklozCost, currency)
                RowTv("السدادات", c.rubberCost, currency)
                RowTv("الزجاج", c.glassCost, currency)
                RowTv("الإكسسوارات", c.accessoryCost, currency)
                RowTv("الأجور", c.laborCost, currency)
                RowTv("النقل", c.transport, currency)
                RowTv("أخرى", c.other, currency)
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                RowTv("إجمالي التكلفة", c.totalCost, currency, bold = true)
                RowTv("الربح (${Calculator.round2((r.profit / c.totalCost * 100).takeIf { c.totalCost > 0 } ?: 0.0)}%)", r.profit, currency)
                RowTv("سعر البيع", r.sellingPrice, currency, bold = true)
            }
        }
    }
}

@Composable
private fun RowTv(k: String, v: Double, cur: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium)
        Text("$v $cur", style = if (bold) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium)
    }
}

// ==================== الإعدادات ====================
@Composable
fun SettingsScreen(nav: NavController) {
    val repo = ServiceLocator.repo
    val wFlow by repo.workshop.collectAsState(initial = null)
    var e by remember { mutableStateOf<WorkshopEntity?>(null) }
    LaunchedEffect(wFlow) { if (e == null) e = wFlow }
    val scope = rememberCoroutineScope()

    ScreenScaffold(nav, "الإعدادات") { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            e?.let { ws ->
                Text("بيانات الورشة", style = MaterialTheme.typography.titleSmall)
                PF("اسم الورشة (عربي)", ws.nameAr) { v -> e = ws.copy(nameAr = v) }
                PF("اسم الورشة (إنجليزي)", ws.name) { v -> e = ws.copy(name = v) }
                PF("الهاتف", ws.phone) { v -> e = ws.copy(phone = v) }
                PF("العنوان", ws.address) { v -> e = ws.copy(address = v) }
                Button({ scope.launch { e?.let { repo.saveWorkshop(it) } } }, Modifier.fillMaxWidth()) { Text("حفظ") }
            }
        }
    }
}
