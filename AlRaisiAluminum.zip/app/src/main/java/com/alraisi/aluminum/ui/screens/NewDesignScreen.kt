package com.alraisi.aluminum.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.alraisi.aluminum.core.model.*
import com.alraisi.aluminum.data.ServiceLocator
import com.alraisi.aluminum.data.db.DesignEntity
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewDesignScreen(nav: NavController) {
    val scope = rememberCoroutineScope()
    val profiles by ServiceLocator.repo.profiles.collectAsState(initial = emptyList())
    val frames = profiles.filter { it.category == "FRAME" }

    var productType by remember { mutableStateOf(ProductType.WINDOW) }
    var shape by remember { mutableStateOf(OpeningShape.RECTANGLE) }
    var width by remember { mutableStateOf("100") }
    var seated by remember { mutableStateOf("100") }
    var total by remember { mutableStateOf("120") }
    var frameId by remember { mutableStateOf("frame_tube44") }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("تصميم جديد") },
            navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(androidx.compose.material.icons.Icons.Default.ArrowBack, "رجوع") } }) }
    ) { pad ->
        Column(
            modifier = Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // نوع المنتج
            Text("نوع المنتج", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = productType == ProductType.WINDOW,
                    onClick = { productType = ProductType.WINDOW }, label = { Text("شباك") })
                FilterChip(selected = productType == ProductType.DOOR,
                    onClick = { productType = ProductType.DOOR }, label = { Text("باب") })
            }

            // شكل الفتحة
            Text("شكل الفتحة", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = shape == OpeningShape.RECTANGLE,
                    onClick = { shape = OpeningShape.RECTANGLE }, label = { Text("فتحة مستطيلة") })
                FilterChip(selected = shape == OpeningShape.ARCH,
                    onClick = { shape = OpeningShape.ARCH }, label = { Text("فتحة مقوّسة (قوس)") })
        }

            // الأبعاد
            OutlinedTextField(
                value = width, onValueChange = { width = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text("العرض (سم)") }, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedTextField(
                value = seated, onValueChange = { seated = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text(if (shape == OpeningShape.ARCH) "الارتفاع الجالس (سم) — حتى بداية القوس" else "الارتفاع (سم)") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            if (shape == OpeningShape.ARCH) {
                OutlinedTextField(
                    value = total, onValueChange = { total = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("الارتفاع الكلي (سم) — حتى أعلى نقطة في القوس") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Text("مثال: عرض 100، جالس 100، كلي 120",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // الإطار
            Text("الإطار (الحلق)", fontWeight = FontWeight.Bold)
            frames.forEach { f ->
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    RadioButton(selected = frameId == f.id, onClick = { frameId = f.id })
                    Text("${f.nameAr} — عرض ${f.widthCm} سم")
                }
            }

            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            Button(
                onClick = {
                    val w = width.toDoubleOrNull()
                    val sh = seated.toDoubleOrNull()
                    val th = if (shape == OpeningShape.ARCH) total.toDoubleOrNull() else sh
                    when {
                        w == null || w <= 0 -> error = "أدخل عرضاً صحيحاً"
                        sh == null || sh <= 0 -> error = "أدخل ارتفاعاً صحيحاً"
                        shape == OpeningShape.ARCH && (th == null || th!! <= sh) ->
                            error = "الارتفاع الكلي يجب أن يكون أكبر من الجالس"
                        else -> {
                            error = null
                            val doc = DesignDocument(
                                id = UUID.randomUUID().toString(),
                                name = if (productType == ProductType.WINDOW) "شباك ${w.toInt()}×${sh.toInt()}" else "باب ${w.toInt()}×${sh.toInt()}",
                                opening = OpeningSpec(
                                    widthCm = w, seatedHeightCm = sh,
                                    totalHeightCm = th ?: sh,
                                    productType = productType, shape = shape
                                ),
                                frameProfileId = frameId
                            )
                            scope.launch {
                                ServiceLocator.repo.saveDesign(
                                    DesignEntity(doc.id, "", doc.name, ServiceLocator.repo.encodeDoc(doc))
                                )
                                nav.navigate("designer/${doc.id}") { popUpTo("home") }
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("إنشاء التصميم والإطار الخارجي", fontWeight = FontWeight.Bold) }

            OutlinedButton(
                onClick = {
                    // المثال الجاهز: 100×100 جالس / 120 كلي، تيوب 4×4، درفتان + قاطع مركزي + ثابتان
                    val doc = DesignDocument(
                        id = UUID.randomUUID().toString(),
                        name = "مثال: شباك مقوس 100×120",
                        opening = OpeningSpec(100.0, 100.0, 120.0, ProductType.WINDOW, OpeningShape.ARCH),
                        frameProfileId = "frame_tube44",
                        components = listOf(
                            CanvasComponent(profileId = "div_large65", kind = ComponentKind.DIVIDER,
                                x = 46.75, y = 4.0, w = 6.5, h = 92.0, name = "قاطع مركزي"),
                            CanvasComponent(profileId = "sash_rolled55", kind = ComponentKind.SASH,
                                x = 8.0, y = 48.0, w = 38.0, h = 44.0, name = "درفة يمنى"),
                            CanvasComponent(profileId = "sash_rolled55", kind = ComponentKind.SASH,
                                x = 54.0, y = 48.0, w = 38.0, h = 44.0, name = "درفة يسرى"),
                            CanvasComponent(profileId = "fixed_std", kind = ComponentKind.FIXED,
                                x = 8.0, y = 8.0, w = 84.0, h = 36.0, name = "ثابت علوي")
                        )
                    )
                    scope.launch {
                        ServiceLocator.repo.saveDesign(DesignEntity(doc.id, "", doc.name, ServiceLocator.repo.encodeDoc(doc)))
                        nav.navigate("designer/${doc.id}") { popUpTo("home") }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("تحميل المثال الجاهز (100×100 جالس / 120 كلي)") }
        }
    }
}
