package com.alraisi.aluminum.ui.screens

import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import com.alraisi.aluminum.core.calc.Calculator
import com.alraisi.aluminum.core.model.*
import com.alraisi.aluminum.data.ServiceLocator
import com.alraisi.aluminum.data.db.WorkshopEntity
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File

@Composable
fun ReportScreen(nav: NavController, designId: String) {
    val repo = ServiceLocator.repo
    var result by remember { mutableStateOf<CalcResult?>(null) }
    var doc by remember { mutableStateOf<DesignDocument?>(null) }
    var workshop by remember { mutableStateOf<WorkshopEntity?>(null) }
    var currency by remember { mutableStateOf("ريال") }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(designId) {
        workshop = repo.workshopOnce()
        val st = repo.settingsOnce()
        currency = st.currency
        doc = repo.designById(designId)?.let { repo.decodeDoc(it.docJson) }
        doc?.let { result = Calculator.calculate(it, repo.profilesOnce(), st, repo.rulesOnce()) }
    }

    ScreenScaffold(nav, "تقرير التصنيع") { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(workshop?.nameAr ?: "", style = MaterialTheme.typography.titleLarge)
            Text("التصميم: ${doc?.name ?: ""} — ${doc?.opening?.widthCm}×${doc?.opening?.effectiveHeight} سم" +
                if (doc?.opening?.shape == OpeningShape.ARCH) " (مقوّس — جالس ${doc?.opening?.seatedHeightCm} سم)" else "")
            result?.let { r ->
                Section("قائمة القص") {
                    r.cuttingList.forEach {
                        L("${it.part} | ${it.profileName} ×${it.quantity} | ${it.lengthCm} سم | قص ${it.angleDeg}° | ${it.location}")
                    }
                }
                Section("الزجاج") { r.glassList.forEach { L("${it.name}: ${it.widthCm} × ${it.heightCm} سم") } }
                Section("البركلوز") {
                    r.berklozList.forEach { L("${it.hostName} — ${it.berklozName}: ${it.lengthCm} سم (${it.pieceCount} قطعة)") }
                }
                Section("الإكسسوارات") { r.accessories.forEach { L("${it.name} ×${it.quantity} = ${it.total} $currency") } }
                Section("مواسير 6 متر — الهالك ${r.totalWasteCm} سم (${r.wastePercent}%)") {
                    r.bars.forEach {
                        L("${it.profileName} ماسورة ${it.barIndex}: " +
                            it.cuts.joinToString(" + ") { c -> "${c.lengthCm}" } +
                            " = ${it.usedCm} سم (باقي ${it.remainingCm})")
                    }
                }
                HorizontalDivider()
                L("التكلفة الإجمالية: ${r.cost.totalCost} $currency", title = true)
                L("سعر البيع: ${r.sellingPrice} $currency — الربح: ${r.profit} $currency", title = true)
                Button(
                    onClick = { scope.launch { exportPdf(context, workshop, doc!!, r, currency) } },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                ) { Text("تصدير / طباعة PDF ومشاركته") }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column { Text(title, style = MaterialTheme.typography.titleSmall); content() }
}

@Composable
private fun L(t: String, title: Boolean = false) {
    Text(t, style = if (title) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodySmall)
}

private fun exportPdf(context: android.content.Context, w: WorkshopEntity?, doc: DesignDocument, r: CalcResult, currency: String) {
    val pdf = PdfDocument()
    val paint = Paint().apply { textSize = 10.5f; typeface = Typeface.DEFAULT }
    val titleP = Paint(paint).apply { textSize = 15f; isFakeBoldText = true; textAlign = Paint.Align.RIGHT }
    val bodyP = Paint(paint).apply { textAlign = Paint.Align.RIGHT }
    val secP = Paint(paint).apply { textSize = 12f; isFakeBoldText = true; textAlign = Paint.Align.RIGHT }

    var page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
    var canvas = page.canvas
    var y = 50f
    var pageNo = 1

    fun newPageIfNeeded() {
        if (y < 790f) return
        pdf.finishPage(page)
        pageNo++
        page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        canvas = page.canvas
        y = 50f
    }
    fun line(t: String, p: android.graphics.Paint = bodyP) {
        newPageIfNeeded()
        canvas.drawText(t, 555f, y, p); y += 15f
    }
    fun section(t: String) { y += 6f; line(t, secP); y += 2f }

    line(w?.nameAr ?: "ورشة الريسي للألومنيوم", titleP)
    line("التصميم: ${doc.name} | ${doc.opening.widthCm}×${doc.opening.effectiveHeight} سم" +
        if (doc.opening.shape == OpeningShape.ARCH) " | مقوّس: جالس ${doc.opening.seatedHeightCm} كلي ${doc.opening.totalHeightCm}" else "")
    section("— قائمة القص —")
    r.cuttingList.forEach { line("${it.part} | ${it.profileName} ×${it.quantity} | ${it.lengthCm} سم | قص ${it.angleDeg}° | ${it.location}") }
    section("— الزجاج —")
    r.glassList.forEach { line("${it.name}: ${it.widthCm} × ${it.heightCm} سم") }
    section("— البركلوز —")
    r.berklozList.forEach { line("${it.hostName} — ${it.berklozName}: ${it.lengthCm} سم (${it.pieceCount} قطعة)") }
    section("— الإكسسوارات —")
    r.accessories.forEach { line("${it.name} ×${it.quantity} = ${it.total} $currency") }
    section("— مواسير 6م — الهالك: ${r.totalWasteCm} سم (${r.wastePercent}%)")
    r.bars.forEach { line("${it.profileName} #${it.barIndex}: " + it.cuts.joinToString("+") { c -> "${c.lengthCm}" } + " = ${it.usedCm} سم (باقي ${it.remainingCm})") }
    section("— التكاليف —")
    line("الألمنيوم: ${r.cost.aluminumCost} | البركلوز: ${r.cost.berklozCost} | السدادات: ${r.cost.rubberCost} | الزجاج: ${r.cost.glassCost} | الإكسسوارات: ${r.cost.accessoryCost} | الأجور: ${r.cost.laborCost} | النقل: ${r.cost.transport} | أخرى: ${r.cost.other}")
    line("الإجمالي: ${r.cost.totalCost} $currency | البيع: ${r.sellingPrice} $currency | الربح: ${r.profit} $currency", secP)

    pdf.finishPage(page)
    val dir = File(context.cacheDir, "reports").apply { mkdirs() }
    val f = File(dir, "report_${doc.id}.pdf")
    val bos = ByteArrayOutputStream()
    pdf.writeTo(bos)
    pdf.close()
    f.writeBytes(bos.toByteArray())
    val uri = FileProvider.getUriForFile(context, "com.alraisi.aluminum.fileprovider", f)
    context.startActivity(Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/pdf")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    })
}
