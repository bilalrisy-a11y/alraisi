package com.alraisi.aluminum.core.calc

import com.alraisi.aluminum.core.model.AccessoryItem
import com.alraisi.aluminum.core.rules.Formula
import com.alraisi.aluminum.data.db.AccessoryRuleEntity

/**
 * محرك الإكسسوارات القائم على قواعد قابلة للتعديل من قاعدة البيانات.
 * شرط التطبيق وكمية كل إكسسوار معادلتان نصيتان.
 */
object AccessoryEngine {

    fun compute(rules: List<AccessoryRuleEntity>, vars: Map<String, Double>): List<AccessoryItem> =
        rules.filter { it.active }.mapNotNull { r ->
            val cond = Formula.eval(r.conditionF, vars)
            if (cond > 0.5) {
                val q = Formula.eval(r.qtyF, vars)
                if (q > 0) AccessoryItem(r.nameAr, r.category, Calculator.round2(q), r.unitPrice) else null
            } else null
        }
}
